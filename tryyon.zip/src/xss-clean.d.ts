declare module 'xss-clean' {
  const value: function;

  export default value;
}
